const mongoose = require("mongoose");

const panelLevelSchema = mongoose.Schema({
  // _id: false,
  panel_level_id: {
    type: String,
    trim: true,
    unique: true,
    lowercase: true,
    required: true,
  },
  panel_level: {
    type: String,
    trim: true,
    unique: true,
    lowercase: true,
    required: true,
  },
  created_by: {
    type: String,
    trim: true,
    lowercase: true,
  },
  created_on: {
    type: Date,
    default: Date.now,
  },
  updated_by: {
    type: String,
    trim: true,
  },
  updated_on: {
    type: Date,
    default: Date.now,
  },
  is_deleted: {
    type: Boolean,
  },
  deleted_by: {
    type: String,
    trim: true,
  },
  deleted_on: {
    type: Date,
    default: Date.now,
  },
});

const panelLevel = mongoose.model(
  "panel_levels",
  panelLevelSchema,
);

module.exports = panelLevel;
